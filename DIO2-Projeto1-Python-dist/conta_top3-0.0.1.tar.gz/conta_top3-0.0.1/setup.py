from setuptools import setup, find_packages

with open("README.md", "r") as f:
    page_description = f.read()

with open("requirements.txt") as f:
    requirements = f.read().splitlines()

setup(
    name="conta_top3",
    version="0.0.1",
    author="grf",
    author_email="grfgrf@protonmail.com",
    description="Retorna as 3 palavras com mais ocorrencia no arquivo .txt",
    long_description=page_description,
    long_description_content_type="text/markdown",
    url="https://github.com/grfgrf/CognizantDIO",
    packages=find_packages(),
    install_requires=requirements,
    python_requires='>=3.8',
)
from collections import Counter
import re

def top3_palavras_txt(caminho):
  with open(caminho,"r") as f:
    listaParagrafo = [paragrafo.strip() for paragrafo in f]
    listaPalavras = list() 
  for paragrafo in listaParagrafo:
  #remove pontuacoes das PALAVRA, append em apenas letras lower()
    [listaPalavras.append(re.sub(r'[^a-z|A-Z]+$|^[^a-z|A-Z]+',"",palavra).lower()) for palavra in paragrafo.split()]
  
  #Conta ocorrencias com collections Counter
  contaPalavra = Counter(listaPalavras)
  listaTOP3 = contaPalavra.most_common(3)
  return(listaTOP3)

